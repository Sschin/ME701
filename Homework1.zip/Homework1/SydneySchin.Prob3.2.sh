#!/bin/bash

#Sydney Schinstock
#Problem 3.2
#Provides count of the number of files and subdirectories in a current directory

#used this command on the command line and it worked. It normally lists number of files with the string value in 'string'. If you leave it blank it counts all of them. 

echo "The number of files and subdirectories in the current directory is:"
ls | grep -c ''

#I ran this shell in various different locations and it worked (as long as I type in the location of this shell script when executing of course---"bash ~/bin/Homework1/SydneySchin.Prob3.2.sh)
