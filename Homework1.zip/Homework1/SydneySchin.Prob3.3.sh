#!/bin/bash

#Sydney Schinstock
#Problem 3.3
#Takes name of file and moves it to the trash directory, creates trash directory if not already there

if [ ! -e "/home/sydney/trash" ]
then
	mkdir /home/sydney/trash
fi

F=$1
P=$PWD
if [ -e "$1" ]
then
	mv $P/$F /home/sydney/trash
else
	echo "Error- File specified does not exist"
fi

#Tested this in a couple of different directories, including a directory not within my home directory, sometimes deleted the /home/sydney/trash directory to see if it was remade and it worked!
